public class Partita extends Thread{
    private String nome;
    public int dado1;
    public int dado2;
    public int tot;

    public Partita() {
    }

    public Partita(String nome) {
        this.nome = nome;
        this.dado1 = dado1;
        this.dado2 = dado2;
        this.tot = tot;
    }

    public String getNome() {
        return this.nome;
    }

    public int getDado1() {
        return this.dado1;
    }

    public int getDado2() {
        return this.dado2;
    }

    public int getTot() {
        return this.tot;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDado1(int dado1) {
        this.dado1 = dado1;
    }

    public void setDado2(int dado2) {
        this.dado2 = dado2;
    }
    
    public void setTot(int tot) {
        this.tot = tot;
    }

    public void run(){
       System.out.println(Thread.currentThread().getName() + " : " + nome + " : sta giocando");
   
    
       do{

        dado1 = (int)(Math.random()*7);
        dado2 = (int)(Math.random()*7);
        System.out.println(getNome() + " ha fatto : " + dado1 + " e : " + dado2);

       }while(dado1 == 0 || dado2 == 0);
       
       do{
           tot= tot + (dado1 + dado2);
           if (dado1 == dado2)
           {
               System.out.println("Lancio bonus per : " + getNome());
               dado1 = (int)(Math.random()*7);
               dado2 = (int)(Math.random()*7);
               System.out.println(getNome() + " ha fatto : " + dado1 + " e : " + dado2);
           }
       }while(dado1 == dado2);

       System.out.println("Il punteggio totale di "+ getNome()+ " è : " + tot);
    }

       
   @Override
    public String toString() {
        return "{" +
            " nome='" + getNome() + "'" +
            ", dado1='" + getDado1() + "'" +
            ", dado2='" + getDado2() + "'" +
            ", tot='" + getTot() + "'" +
            "}";
    }


}
