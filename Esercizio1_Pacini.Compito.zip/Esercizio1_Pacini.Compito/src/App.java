public class App {
    public static void main(String[] args) throws Exception {
        
        Partita p1 = new Partita ("gino");
        Partita p2 = new Partita ("gianni");

        System.out.println("Partita iniziata!");

        p1.start();
        p2.start();

        p1.join();
        p2.join();

        
        System.out.println("Partita terminata!");
    }
}
